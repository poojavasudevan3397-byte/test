"""
Cricbuzz API Integration Module
Handles all API calls to Cricbuzz Cricket API via RapidAPI
"""

# Touch file to prompt language-server refresh (no functional change)
import requests
import streamlit as st
from typing import TYPE_CHECKING, Dict, Any, List, cast, Optional
import pandas as pd #type: ignore

# Treat Streamlit's dynamic members as Any so Pylance won't warn about
# unknown member types like `markdown`, `warning`, `cache_resource`, etc.
st = cast(Any, st)

if TYPE_CHECKING:
    # Import types only for type checking to avoid runtime import cycles
    from .db_connection import DatabaseConnection  # type: ignore

class CricbuzzAPI:
    """Interface for Cricbuzz Cricket API"""

    def __init__(self, api_key: str):
        """Initialize API client with RapidAPI key"""
        self.api_key = api_key
        self.api_host = "cricbuzz-cricket.p.rapidapi.com"
        self.base_url = f"https://{self.api_host}"
        self.headers = {
            "X-RapidAPI-Key": api_key,
            "X-RapidAPI-Host": self.api_host,
        }
        self.timeout = 10

    def get_live_matches(self) -> Dict[str, Any]:
        """Fetch live matches"""
        try:
            url = f"{self.base_url}/matches/v1/live"
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            # Use the exception variable so static analyzers see it's accessed
            st.error(f"Failed to fetch live matches: {e}")
            return {}

    def get_upcoming_matches(self) -> Dict[str, Any]:
        """Fetch upcoming matches"""
        try:
            url = f"{self.base_url}/matches/v1/upcoming"
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            st.error(f"Failed to fetch upcoming matches: {e}")
            return {}

    def get_recent_matches(self) -> Dict[str, Any]:
        """Fetch recent matches"""
        try:
            url = f"{self.base_url}/matches/v1/recent"
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            st.error(f"Failed to fetch recent matches: {e}")
            return {}

    def get_scorecard(self, match_id: str) -> Dict[str, Any]:
        """Fetch scorecard for a specific match"""
        try:
            url = f"{self.base_url}/mcenter/v1/{match_id}/scard"
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            st.warning(f"Failed to fetch scorecard for match {match_id}: {e}")
            return {}

    def get_series(self) -> Dict[str, Any]:
        """Fetch cricket series information"""
        try:
            url = f"{self.base_url}/series/v1"
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            st.error(f"Failed to fetch series: {e}")
            return {}

    def get_player(self, player_id: str) -> Dict[str, Any]:
        """Fetch player information by player id from the Cricbuzz API.

        The RapidAPI endpoint is /stats/v1/player/{player_id}.
        Returns the parsed JSON on success or an empty dict on failure.
        """
        try:
            url = f"{self.base_url}/stats/v1/player/{player_id}"
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            st.error(f"Failed to fetch player {player_id}: {e}")
            return {}

    def sync_player_to_db(self, player_id: str, db_conn: 'DatabaseConnection', team_id: int = 0) -> int:
        """Fetch a player from the API and insert/update it into the `players` table.

        Args:
            player_id: The external player id used by the API.
            db_conn: An instance of `DatabaseConnection` (or MySQL variant) to operate on.
            team_id: Optional team id to associate with the player record (default 0).

        Returns:
            The local `player_id` (SQLite autoincrement or MySQL last insert id) on success, or 0 on failure.
        """
        import json
        # Avoid circular imports at module-import time by importing here
        try:
            # Fetch data from API
            data = self.get_player(str(player_id))
            if not data:
                return 0

            # API may return player info as top-level or under the 'player' key
            raw_payload = data.get("player", data)
            if not isinstance(raw_payload, dict):
                return 0
            player_payload: Dict[str, Any] = cast(Dict[str, Any], raw_payload)

            # Heuristics for field names in the response
            player_name: str = cast(str, player_payload.get("fullName") or
                                    player_payload.get("name") or
                                    player_payload.get("playerName") or
                                    player_payload.get("displayName") or
                                    "")
            country: str = cast(str, player_payload.get("country") or player_payload.get("countryName") or "")
            role: str = cast(str, player_payload.get("role") or "")
            batting_style: str = cast(str, player_payload.get("battingStyle") or player_payload.get("batting_style") or "")
            bowling_style: str = cast(str, player_payload.get("bowlingStyle") or player_payload.get("bowling_style") or "")

            try:
                meta: str = json.dumps(player_payload)
            except Exception:
                meta = str(player_payload)

            if not player_name:
                st.warning(f"Player {player_id} returned no name; skipping insert")
                return 0

            # Determine whether the DB stores an external_player_id column
            has_external: bool = False
            try:
                cols_df = db_conn.execute_query("SELECT * FROM players LIMIT 1")
                has_external = "external_player_id" in set(cols_df.columns)
            except Exception:
                has_external = False

            local_id: int = 0

            # Prefer matching by external_player_id when column exists
            if has_external:
                # Debug: log that we are using external_player_id
                try:
                    print(f"[sync] has_external True, looking for external_player_id={player_id}")
                except Exception:
                    pass

                # Use a direct numeric literal for MySQL engine queries to avoid param-style incompatibilities
                if getattr(db_conn, "db_type", "sqlite") == "mysql":
                    try:
                        select_sql = f"SELECT * FROM players WHERE external_player_id = {int(player_id)}"
                        print(f"[sync] executing: {select_sql}")
                        existing = db_conn.execute_query(select_sql)
                    except Exception:
                        existing = db_conn.execute_query("SELECT * FROM players WHERE external_player_id = %s", (player_id,))
                else:
                    existing = db_conn.execute_query("SELECT * FROM players WHERE external_player_id = ?", (player_id,))

                if not existing.empty:
                    # Determine primary key column name
                    pk_col: Optional[str] = "player_id" if "player_id" in existing.columns else ("id" if "id" in existing.columns else None)
                    if pk_col:
                        try:
                            local_id = int(existing.iloc[0][pk_col])  # type: ignore[index]
                            try:
                                print(f"[sync] found existing local_id={local_id} by external_player_id")
                            except Exception:
                                pass
                        except Exception:
                            local_id = 0

            # Fallback: match by player name
            if local_id == 0:
                select_sql = (
                    "SELECT * FROM players WHERE player_name = %s"
                    if getattr(db_conn, "db_type", "sqlite") == "mysql"
                    else "SELECT * FROM players WHERE player_name = ?"
                )
                existing = db_conn.execute_query(select_sql, (player_name,))
                if not existing.empty:
                    pk_col = "player_id" if "player_id" in existing.columns else ("id" if "id" in existing.columns else None)
                    if pk_col:
                        try:
                            local_id = int(existing.iloc[0][pk_col])  # type: ignore[index]
                        except Exception:
                            local_id = 0

            if local_id:
                # Update existing record (best-effort; do not fail sync if update throws)
                try:
                    db_conn.update_player(
                        int(local_id),
                        country=str(country),
                        role=str(role),
                        batting_style=str(batting_style),
                        bowling_style=str(bowling_style),
                        # If DB has external_player_id but the existing row is missing it, set it
                        **({"external_player_id": int(player_id)} if has_external else {}),
                    )
                except Exception as e:
                    try:
                        print(f"[sync] update_player raised: {e}")
                    except Exception:
                        pass
                return int(local_id)

            # Insert new player
            new_id: int = 0
            if getattr(db_conn, "db_type", "sqlite") == "mysql":
                # MySQL insert signature differs; it will detect columns and insert accordingly
                try:
                    # MySQLDatabaseConnection.insert_player supports the (player_name, country, role, batting_style, bowling_style) signature
                    new_id = int(db_conn.insert_player(player_name, country, role, batting_style, bowling_style))  # type: ignore[arg-type]
                except TypeError:
                    # Fallback to generic insert via insert_player signature with team_id
                    new_id = int(db_conn.insert_player(0, player_name, country, role, batting_style, bowling_style, meta))  # type: ignore[arg-type]
                except Exception:
                    new_id = 0
            else:
                try:
                    new_id = int(db_conn.insert_player(team_id, player_name, country, role, batting_style, bowling_style, meta))
                except Exception:
                    new_id = 0

            # If insert did not return an id but DB has `external_player_id`, try to locate the row by name
            if has_external and not new_id:
                try:
                    select_sql = (
                        "SELECT * FROM players WHERE player_name = %s"
                        if getattr(db_conn, "db_type", "sqlite") == "mysql"
                        else "SELECT * FROM players WHERE player_name = ?"
                    )
                    existing = db_conn.execute_query(select_sql, (player_name,))
                    if not existing.empty:
                        pk_col = "player_id" if "player_id" in existing.columns else ("id" if "id" in existing.columns else None)
                        if pk_col:
                            try:
                                new_id = int(existing.iloc[0][pk_col])  # type: ignore[index]
                            except Exception:
                                new_id = 0
                except Exception:
                    pass

            # If DB exposes external_player_id column, set it for the newly inserted (or located) row
            if has_external and new_id:
                try:
                    db_conn.update_player(new_id, external_player_id=int(player_id))
                except Exception:
                    # best-effort: ignore failures
                    pass

            return new_id
        except Exception as e:
            st.error(f"Failed to sync player {player_id} to DB: {e}")
            return 0


@st.cache_resource
def get_api_client(api_key: str) -> CricbuzzAPI:
    """Get cached API client instance"""
    return CricbuzzAPI(api_key)


def normalize_matches(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Normalize API response into a flat list of matches
    
    Args:
        data: Raw API response
        
    Returns:
        List of normalized match dictionaries
    """
    matches: List[Dict[str, Any]] = []
    
    for type_match in data.get('typeMatches', []):
        match_type = type_match.get('matchType', 'Unknown')
        
        for series in type_match.get('seriesMatches', []):
            if 'ad' in series:
                continue
                
            wrapper = series.get('seriesAdWrapper', series)
            series_name = wrapper.get('seriesName', 'N/A')
            series_id = wrapper.get('seriesId', '')
            
            for match in wrapper.get('matches', []):
                match_info = match.get('matchInfo', {})
                match_score = match.get('matchScore', {})
                
                team1 = match_info.get('team1', {})
                team2 = match_info.get('team2', {})
                venue = match_info.get('venueInfo', {})
                
                t1_score = match_score.get('team1Score', {})
                t2_score = match_score.get('team2Score', {})
                
                match_data: Dict[str, Any] = {
                    'matchType': match_type,
                    'seriesId': series_id,
                    'seriesName': series_name,
                    'matchId': match_info.get('matchId', ''),
                    'matchDesc': match_info.get('matchDesc', ''),
                    'matchFormat': match_info.get('matchFormat', ''),
                    'startDate': match_info.get('startDate'),
                    'endDate': match_info.get('endDate'),
                    'state': match_info.get('state', 'N/A'),
                    'status': match_info.get('status', 'N/A'),
                    'team1_name': team1.get('teamName', 'N/A'),
                    'team2_name': team2.get('teamName', 'N/A'),
                    'team1_short': team1.get('teamSName', ''),
                    'team2_short': team2.get('teamSName', ''),
                    'team1_id': team1.get('teamId', ''),
                    'team2_id': team2.get('teamId', ''),
                    'venue': venue.get('ground', 'N/A'),
                    'city': venue.get('city', 'N/A'),
                    'country': venue.get('country', 'N/A'),
                    'team1_score': t1_score.get('inngs1', {}).get('runs', 'N/A'),
                    'team1_wickets': t1_score.get('inngs1', {}).get('wickets', 'N/A'),
                    'team1_overs': t1_score.get('inngs1', {}).get('overs', 'N/A'),
                    'team2_score': t2_score.get('inngs1', {}).get('runs', 'N/A'),
                    'team2_wickets': t2_score.get('inngs1', {}).get('wickets', 'N/A'),
                    'team2_overs': t2_score.get('inngs1', {}).get('overs', 'N/A'),
                }
                
                matches.append(match_data)  # type: ignore[attr-defined]
    
    return matches
